package com.example.fisspringboot.fisspringbootdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FisspringbootdemoApplicationTests {

	@Test
	void contextLoads() {
	}
	
	// other unit testing realted code 

}
