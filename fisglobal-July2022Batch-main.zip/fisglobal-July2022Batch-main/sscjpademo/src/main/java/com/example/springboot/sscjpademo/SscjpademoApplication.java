package com.example.springboot.sscjpademo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SscjpademoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SscjpademoApplication.class, args);
	}

}
