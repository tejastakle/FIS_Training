package com.example.springboot.sscjpademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SscjpademoApplicationTests {

	@Test
	void contextLoads() {
	}

}
