package javaannotations;

import org.springframework.stereotype.Component;

@Component
public class EmpServiceImpl implements EmpService {

	public void getServiceType() {
		// TODO Auto-generated method stub
		System.out.println("Employee type is permanent");

	}

}
