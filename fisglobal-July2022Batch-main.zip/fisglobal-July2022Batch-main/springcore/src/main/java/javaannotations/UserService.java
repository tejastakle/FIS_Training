package javaannotations;

public interface UserService {
	
	public String getServiceType();
}
