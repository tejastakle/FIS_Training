package javaannotations;

public interface EmpService {
	public void getServiceType();
}
