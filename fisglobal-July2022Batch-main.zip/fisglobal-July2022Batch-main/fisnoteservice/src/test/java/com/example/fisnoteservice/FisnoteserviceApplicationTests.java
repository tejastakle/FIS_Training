package com.example.fisnoteservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FisnoteserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
