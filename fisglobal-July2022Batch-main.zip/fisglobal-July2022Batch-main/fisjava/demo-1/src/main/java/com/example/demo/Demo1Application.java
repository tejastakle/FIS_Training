package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class Demo1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo1Application.class, args);
	}
	
	@GetMapping("/test")
	public String gets() {
		String str="hai";
		Object obj = new Object();
		
		try {
			
		} finally {
			// TODO: handle finally clause
		}
		return "Same old Hello World...";
		 
		
	}

}
