package java8;

public class ExceptionHandle1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=0,c;
		c=a/b;
		System.out.println("The division is : "+c);
		System.out.println("After the division...");
		String str =null;
		if(str.equals("praveen"))
			System.out.println("equal string..");
		else
			System.out.println("unequal string..");

	}

}
