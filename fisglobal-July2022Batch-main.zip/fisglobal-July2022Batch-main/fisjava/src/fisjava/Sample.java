package fisjava;
import java.util.Scanner;
public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello world....");
		System.out.println("Hello another world.......");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your name...");
		String name = sc.next();
		System.out.println(name);
	}
}
