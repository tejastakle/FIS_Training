package fisjava;

public class Shopping {
	
	public void selectGoods() {
		
		System.out.println("Items are to be selected from store..");
	}
	
	public void payment() {
		System.out.println("only cash is accepted...");
	}
	
	public void shipment() {
		System.out.println("no shipping is allowed, you have to carry with you..");
	}
}
